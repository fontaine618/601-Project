DE GRUYTER LaTeX template archive
=================================

This is file 00README.txt.

Files within this archive are listed below with a brief description.

00README.txt     - This file. Package contents with descriptions.

dgjournal.sty   - The bepress bejournal LaTeX package
DeGruyter.bst    - The bepress BibTeX style file

sample.bib	 - A sample BibTeX bibliography database

dg_template.tex	 - A template for author use. Edit this file and follow
		   instructions provided within
dg_template.bbl	 - The generated BibTeX bibliography file of the template
dg_template.pdf	 - The PDF generated from the template file

